﻿class Program
{
    static List<BankAccount> accounts = new List<BankAccount>();

    static void Main()
    {
        int choice;
        BankAccount selectedAccount = null;

        do
        {
            Console.WriteLine("\nВыберите действие:");
            Console.WriteLine("1. Создать новый счет");
            Console.WriteLine("2. Выбрать счет для взаимодействия");
            Console.WriteLine("0. Выход");

            if (int.TryParse(Console.ReadLine(), out choice))
            {
                switch (choice)
                {
                    case 1:
                        CreateNewAccount();
                        break;
                    case 2:
                        selectedAccount = SelectAccount();
                        if (selectedAccount != null)
                        {
                            selectedAccount.HandleAccountActions();
                        }
                        break;
                    case 0:
                        Console.WriteLine("Программа завершена.");
                        break;
                    default:
                        Console.WriteLine("Некорректный выбор. Попробуйте снова.");
                        break;
                }
            }
            else
            {
                Console.WriteLine("Ошибка ввода. Введите целое число.");
            }
        } while (choice != 0);
    }

    static void CreateNewAccount()
    {
        BankAccount newAccount = new BankAccount();
        Console.WriteLine("Введите номер счета:");
        int accountNumber = int.Parse(Console.ReadLine());

        Console.WriteLine("Введите ФИО владельца счета:");
        string ownerName = Console.ReadLine();

        Console.WriteLine("Введите начальный баланс счета:");
        float initialBalance = float.Parse(Console.ReadLine());

        newAccount.OpenAccount(accountNumber, ownerName, initialBalance);
        accounts.Add(newAccount);
        Console.WriteLine($"Счет #{accountNumber} успешно создан.");
    }

    static BankAccount SelectAccount()
    {
        Console.WriteLine("Введите номер счета для взаимодействия:");
        int accountNumber = int.Parse(Console.ReadLine());

        BankAccount selectedAccount = GetAccountByNumber(accountNumber);
        if (selectedAccount == null)
        {
            Console.WriteLine("Счет с указанным номером не найден.");
        }

        return selectedAccount;
    }

    public static BankAccount GetAccountByNumber(int accountNumber)
    {
        return accounts.Find(a => a.AccountNumber == accountNumber);
    }
}