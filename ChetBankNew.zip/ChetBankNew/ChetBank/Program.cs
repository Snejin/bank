﻿class Program
{
    static List<BankAccount> accounts = new List<BankAccount>();

    static void Main()
    {
        int choice;
        BankAccount selectedAccount = null;

        do
        {
            Console.WriteLine("\nВыберите действие:");
            Console.WriteLine("1. Создать новый счет");
            Console.WriteLine("2. Выбрать счет для взаимодействия");
            Console.WriteLine("0. Выход");

            if (int.TryParse(Console.ReadLine(), out choice))
            {
                switch (choice)
                {
                    case 1:
                        CreateNewAccount();
                        break;
                    case 2:
                        selectedAccount = SelectAccount();
                        if (selectedAccount != null)
                        {
                            HandleSelectedAccount(selectedAccount);
                        }
                        break;
                    case 0:
                        Console.WriteLine("Программа завершена.");
                        break;
                    default:
                        Console.WriteLine("Некорректный выбор. Попробуйте снова.");
                        break;
                }
            }
            else
            {
                Console.WriteLine("Ошибка ввода. Введите целое число.");
            }
        } while (choice != 0);
    }

    static void CreateNewAccount()
    {
        BankAccount newAccount = new BankAccount();
        Console.WriteLine("Введите номер счета:");
        int accountNumber = int.Parse(Console.ReadLine());

        Console.WriteLine("Введите ФИО владельца счета:");
        string ownerName = Console.ReadLine();

        Console.WriteLine("Введите начальный баланс счета:");
        float initialBalance = float.Parse(Console.ReadLine());

        newAccount.OpenAccount(accountNumber, ownerName, initialBalance);
        accounts.Add(newAccount);
        Console.WriteLine($"Счет #{accountNumber} успешно создан.");
    }

    static BankAccount SelectAccount()
    {
        Console.WriteLine("Введите номер счета для взаимодействия:");
        int accountNumber = int.Parse(Console.ReadLine());

        BankAccount selectedAccount = accounts.Find(a => a.AccountNumber == accountNumber);
        if (selectedAccount == null)
        {
            Console.WriteLine("Счет с указанным номером не найден.");
        }

        return selectedAccount;
    }

    static void HandleSelectedAccount(BankAccount selectedAccount)
    {
        int choice;
        do
        {
            Console.WriteLine($"\nВыберите действие для счета #{selectedAccount.AccountNumber} ({selectedAccount.OwnerName}):");
            Console.WriteLine("1. Показать информацию о счете");
            Console.WriteLine("2. Положить деньги на счет");
            Console.WriteLine("3. Снять деньги со счета");
            Console.WriteLine("4. Взять все деньги со счета");
            Console.WriteLine("5. Перевести деньги на другой счет");
            Console.WriteLine("0. Вернуться к выбору счета");

            if (int.TryParse(Console.ReadLine(), out choice))
            {
                switch (choice)
                {
                    case 1:
                        selectedAccount.ShowAccountInfo();
                        break;
                    case 2:
                        DepositMoney(selectedAccount);
                        break;
                    case 3:
                        WithdrawMoney(selectedAccount);
                        break;
                    case 4:
                        WithdrawAllMoney(selectedAccount);
                        break;
                    case 5:
                        TransferMoney(selectedAccount);
                        break;
                    case 0:
                        Console.WriteLine("Возвращение к выбору счета.");
                        break;
                    default:
                        Console.WriteLine("Некорректный выбор. Попробуйте снова.");
                        break;
                }
            }
            else
            {
                Console.WriteLine("Ошибка ввода. Введите целое число.");
            }
        } while (choice != 0);
    }

    static void DepositMoney(BankAccount account)
    {
        Console.WriteLine("Введите сумму для пополнения:");
        if (float.TryParse(Console.ReadLine(), out float depositAmount))
        {
            account.Deposit(depositAmount);
        }
        else
        {
            Console.WriteLine("Ошибка ввода суммы.");
        }
    }

    static void WithdrawMoney(BankAccount account)
    {
        Console.WriteLine("Введите сумму для снятия:");
        if (float.TryParse(Console.ReadLine(), out float withdrawAmount))
        {
            account.Withdraw(withdrawAmount);
        }
        else
        {
            Console.WriteLine("Ошибка ввода суммы.");
        }
    }

    static void WithdrawAllMoney(BankAccount account)
    {
        account.WithdrawAll();
    }

    static void TransferMoney(BankAccount sourceAccount)
    {
        Console.WriteLine("Введите номер счета получателя:");
        int destinationAccountNumber = int.Parse(Console.ReadLine());

        BankAccount destinationAccount = accounts.Find(a => a.AccountNumber == destinationAccountNumber);
        if (destinationAccount != null)
        {
            Console.WriteLine("Введите сумму для перевода:");
            if (float.TryParse(Console.ReadLine(), out float transferAmount))
            {
                sourceAccount.Transfer(destinationAccount, transferAmount);
            }
            else
            {
                Console.WriteLine("Ошибка ввода суммы.");
            }
        }
        else
        {
            Console.WriteLine("Счет получателя не найден.");
        }
    }
}