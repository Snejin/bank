﻿class Program
{
    static List<BankAccount> accounts = new List<BankAccount>();

    static void Main()
    {
        int choice;
        BankAccount selectedAccount = null;

        do
        {
            Console.WriteLine("\nВыберите действие:");
            Console.WriteLine("1. Создать новый счет");
            Console.WriteLine("2. Выбрать счет для взаимодействия");
            Console.WriteLine("0. Выход");

            if (int.TryParse(Console.ReadLine(), out choice))
            {
                switch (choice)
                {
                    case 1:
                        CreateNewAccount();
                        break;
                    case 2:
                        selectedAccount = BankAccount.SelectAccount(accounts);
                        if (selectedAccount != null)
                        {
                            selectedAccount.HandleAccountActions();
                        }
                        break;
                    case 0:
                        Console.WriteLine("Программа завершена.");
                        break;
                    default:
                        Console.WriteLine("Некорректный выбор. Попробуйте снова.");
                        break;
                }
            }
            else
            {
                Console.WriteLine("Ошибка ввода. Введите целое число.");
            }
        } while (choice != 0);
    }

    static void CreateNewAccount()
    {
        BankAccount newAccount = new BankAccount();
        newAccount.CreateNewAccount();
        accounts.Add(newAccount);
    }
    
    public static BankAccount GetAccountByNumber(int accountNumber)
    {
        return accounts.Find(a => a.AccountNumber == accountNumber);
    }
}