﻿class Program
{
    static List<BankAccount> accounts = new List<BankAccount>();

    static void Main()
    {
        int choice;
        do
        {
            Console.WriteLine("\nВыберите действие:");
            Console.WriteLine("1. Создать новый счет");
            Console.WriteLine("2. Показать информацию о счете");
            Console.WriteLine("3. Положить деньги на счет");
            Console.WriteLine("4. Снять деньги со счета");
            Console.WriteLine("5. Взять все деньги со счета");
            Console.WriteLine("6. Перевести деньги на другой счет");
            Console.WriteLine("0. Выход");

            if (int.TryParse(Console.ReadLine(), out choice))
            {
                switch (choice)
                {
                    case 1:
                        CreateNewAccount();
                        break;
                    case 2:
                        ShowAccountInfo();
                        break;
                    case 3:
                        DepositMoney();
                        break;
                    case 4:
                        WithdrawMoney();
                        break;
                    case 5:
                        WithdrawAllMoney();
                        break;
                    case 6:
                        TransferMoney();
                        break;
                    case 0:
                        Console.WriteLine("Программа завершена.");
                        break;
                    default:
                        Console.WriteLine("Некорректный выбор. Попробуйте снова.");
                        break;
                }
            }
            else
            {
                Console.WriteLine("Ошибка ввода. Введите целое число.");
            }
        } while (choice != 0);
    }

    static void CreateNewAccount()
    {
        BankAccount newAccount = new BankAccount();
        Console.WriteLine("Введите номер счета:");
        int accountNumber = int.Parse(Console.ReadLine());

        Console.WriteLine("Введите ФИО владельца счета:");
        string ownerName = Console.ReadLine();

        Console.WriteLine("Введите начальный баланс счета:");
        float initialBalance = float.Parse(Console.ReadLine());

        newAccount.OpenAccount(accountNumber, ownerName, initialBalance); accounts.Add(newAccount);
        Console.WriteLine($"Счет #{accountNumber} успешно создан.");
    }

    static void ShowAccountInfo()
    {
        Console.WriteLine("Введите номер счета:");
        int accountNumber = int.Parse(Console.ReadLine());

        BankAccount account = accounts.Find(a => a.AccountNumber == accountNumber);
        if (account != null)
        {
            account.ShowAccountInfo();
        }
        else
        {
            Console.WriteLine("Счет с указанным номером не найден.");
        }
    }

    static void DepositMoney()
    {
        Console.WriteLine("Введите номер счета:");
        int accountNumber = int.Parse(Console.ReadLine());

        BankAccount account = accounts.Find(a => a.AccountNumber == accountNumber);
        if (account != null)
        {
            Console.WriteLine("Введите сумму для пополнения:");
            float depositAmount = float.Parse(Console.ReadLine());
            account.Deposit(depositAmount);
        }
        else
        {
            Console.WriteLine("Счет с указанным номером не найден.");
        }
    }

    static void WithdrawMoney()
    {
        Console.WriteLine("Введите номер счета:");
        int accountNumber = int.Parse(Console.ReadLine());

        BankAccount account = accounts.Find(a => a.AccountNumber == accountNumber);
        if (account != null)
        {
            Console.WriteLine("Введите сумму для снятия:");
            float withdrawAmount = float.Parse(Console.ReadLine());
            account.Withdraw(withdrawAmount);
        }
        else
        {
            Console.WriteLine("Счет с указанным номером не найден.");
        }
    }

    static void WithdrawAllMoney()
    {
        Console.WriteLine("Введите номер счета:");
        int accountNumber = int.Parse(Console.ReadLine());

        BankAccount account = accounts.Find(a => a.AccountNumber == accountNumber);
        if (account != null)
        {
            account.WithdrawAll();
        }
        else
        {
            Console.WriteLine("Счет с указанным номером не найден.");
        }
    }

    static void TransferMoney()
    {
        Console.WriteLine("Введите номер счета отправителя:");
        int sourceAccountNumber = int.Parse(Console.ReadLine());

        Console.WriteLine("Введите номер счета получателя:");
        int destinationAccountNumber = int.Parse(Console.ReadLine());

        BankAccount sourceAccount = accounts.Find(a => a.AccountNumber == sourceAccountNumber);
        BankAccount destinationAccount = accounts.Find(a => a.AccountNumber == destinationAccountNumber);

        if (sourceAccount != null && destinationAccount != null)
        {
            Console.WriteLine("Введите сумму для перевода:");
            float transferAmount = float.Parse(Console.ReadLine());
            sourceAccount.Transfer(destinationAccount, transferAmount);
        }
        else
        {
            Console.WriteLine("Один из счетов не найден.");
        }
    }
}