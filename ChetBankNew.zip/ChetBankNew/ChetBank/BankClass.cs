﻿using System;
using System.Collections.Generic;

class BankAccount
{
    private int accountNumber;
    private string ownerName;
    private float balance;

    public int AccountNumber
    {
        get { return accountNumber; }
    }

    public string OwnerName
    {
        get { return ownerName; }
    }

    public void OpenAccount(int accountNumber, string ownerName, float initialBalance)
    {
        this.accountNumber = accountNumber;
        this.ownerName = ownerName;
        this.balance = initialBalance;
    }

    public void ShowAccountInfo()
    {
        Console.WriteLine($"Счет #{accountNumber} на имя {ownerName}. Баланс: {balance} р");
    }

    public void Deposit(float amount)
    {
        if (amount > 0)
        {
            balance += amount;
            Console.WriteLine($"На счет поступило: {amount} р");
        }
        else
        {
            Console.WriteLine("Ошибка: сумма должна быть положительной.");
        }
    }

    public void Withdraw(float amount)
    {
        if (amount > 0 && amount <= balance)
        {
            balance -= amount;
            Console.WriteLine($"Со счета снято: {amount} р");
        }
        else
        {
            Console.WriteLine("Ошибка: недостаточно средств на счете.");
        }
    }

    public void WithdrawAll()
    {
        Console.WriteLine($"Все средства со счета сняты: {balance} р");
        balance = 0;
    }

    public void Transfer(BankAccount destinationAccount, float amount)
    {
        if (amount > 0 && amount <= balance)
        {
            Withdraw(amount);
            destinationAccount.Deposit(amount);
            Console.WriteLine($"Перевод выполнен успешно: {amount}");
        }
        else
        {
            Console.WriteLine("Ошибка при переводе: недостаточно средств.");
        }
    }
}

