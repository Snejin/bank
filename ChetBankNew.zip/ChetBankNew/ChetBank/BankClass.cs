﻿using System;
using System.Collections.Generic;

class BankAccount
{
    private int accountNumber;
    private string ownerName;
    private float balance;

    public int AccountNumber
    {
        get { return accountNumber; }
    }

    public string OwnerName
    {
        get { return ownerName; }
    }

    public void CreateNewAccount()
    {
        Console.WriteLine("Введите номер счета:");
        accountNumber = int.Parse(Console.ReadLine());

        Console.WriteLine("Введите ФИО владельца счета:");
        ownerName = Console.ReadLine();

        Console.WriteLine("Введите начальный баланс счета:");
        balance = float.Parse(Console.ReadLine());

        Console.WriteLine($"Счет #{accountNumber} на имя {ownerName} успешно создан.");
    }

    public static BankAccount SelectAccount(List<BankAccount> accounts)
    {
        Console.WriteLine("Введите номер счета для взаимодействия:");
        int accountNumber = int.Parse(Console.ReadLine());

        BankAccount selectedAccount = accounts.Find(a => a.AccountNumber == accountNumber);
        if (selectedAccount == null)
        {
            Console.WriteLine("Счет с указанным номером не найден.");
        }

        return selectedAccount;
    }

    public void ShowAccountInfo()
    {
        Console.WriteLine($"Счет #{accountNumber} на имя {ownerName}. Баланс: {balance:C2}");
    }

    public void Deposit(float amount)
    {
        if (amount > 0)
        {
            balance += amount;
            Console.WriteLine($"На счет поступило: {amount:C2}");
        }
        else
        {
            Console.WriteLine("Ошибка: сумма должна быть положительной.");
        }
    }

    public void Withdraw(float amount)
    {
        if (amount > 0 && amount <= balance)
        {
            balance -= amount;
            Console.WriteLine($"Со счета снято: {amount:C2}");
        }
        else
        {
            Console.WriteLine("Ошибка: недостаточно средств на счете.");
        }
    }

    public void WithdrawAll()
    {
        Console.WriteLine($"Все средства со счета сняты: {balance:C2}");
        balance = 0;
    }

    public void Transfer(BankAccount destinationAccount, float amount)
    {
        if (amount > 0 && amount <= balance)
        {
            Withdraw(amount);
            destinationAccount.Deposit(amount);
            Console.WriteLine($"Перевод выполнен успешно: {amount:C2}");
        }
        else
        {
            Console.WriteLine("Ошибка при переводе: недостаточно средств.");
        }
    }

    public void HandleAccountActions()
    {
        int choice;
        do
        {
            Console.WriteLine($"\nВыберите действие для счета #{accountNumber} ({ownerName}):");
            Console.WriteLine("1. Показать информацию о счете");
            Console.WriteLine("2. Положить деньги на счет");
            Console.WriteLine("3. Снять деньги со счета");
            Console.WriteLine("4. Взять все деньги со счета");
            Console.WriteLine("5. Перевести деньги на другой счет");
            Console.WriteLine("0. Вернуться к выбору счета");

            if (int.TryParse(Console.ReadLine(), out choice))
            {
                switch (choice)
                {
                    case 1:
                        ShowAccountInfo();
                        break;
                    case 2:
                        DepositMoney();
                        break;
                    case 3:
                        WithdrawMoney();
                        break;
                    case 4:
                        WithdrawAllMoney();
                        break;
                    case 5:
                        TransferMoney();
                        break;
                    case 0:
                        Console.WriteLine("Возвращение к выбору счета.");
                        break;
                    default:
                        Console.WriteLine("Некорректный выбор. Попробуйте снова.");
                        break;
                }
            }
            else
            {
                Console.WriteLine("Ошибка ввода. Введите целое число.");
            }
        } while (choice != 0);
    }

    private void DepositMoney()
    {
        Console.WriteLine("Введите сумму для пополнения:");
        if (float.TryParse(Console.ReadLine(), out float depositAmount))
        {
            Deposit(depositAmount);
        }
        else
        {
            Console.WriteLine("Ошибка ввода суммы.");
        }
    }

    private void WithdrawMoney()
    {
        Console.WriteLine("Введите сумму для снятия:");
        if (float.TryParse(Console.ReadLine(), out float withdrawAmount))
        {
            Withdraw(withdrawAmount);
        }
        else
        {
            Console.WriteLine("Ошибка ввода суммы.");
        }
    }

    private void WithdrawAllMoney()
    {
        WithdrawAll();
    }

    private void TransferMoney()
    {
        Console.WriteLine("Введите номер счета получателя:");
        int destinationAccountNumber = int.Parse(Console.ReadLine());

        BankAccount destinationAccount = Program.GetAccountByNumber(destinationAccountNumber);
        if (destinationAccount != null)
        {
            Console.WriteLine("Введите сумму для перевода:");
            if (float.TryParse(Console.ReadLine(), out float transferAmount))
            {
                Transfer(destinationAccount, transferAmount);
            }
            else
            {
                Console.WriteLine("Ошибка ввода суммы.");
            }
        }
        else
        {
            Console.WriteLine("Счет получателя не найден.");
        }
    }
}

